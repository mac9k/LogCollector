adb -s 0123456789ABCDEF reboot
adb -s 60000005 reboot
adb -s 60000065 reboot
